# Android-Project
Having a go at creating android apps in Android Studion 3.5.
In this file is the .src code of the Adroid app im making, it is an app of basic things as
it is my first go at making apps in Adroid Studio.
-----------------------------------------------
Version 1:
Hello World
